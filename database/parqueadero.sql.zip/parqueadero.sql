-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-12-2020 a las 02:21:12
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.1

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `parqueadero`
--
CREATE DATABASE IF NOT EXISTS `parqueadero` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `parqueadero`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parqueadero`
--

DROP TABLE IF EXISTS `parqueadero`;
CREATE TABLE IF NOT EXISTS `parqueadero` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num_cedula` varchar(10) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `telefono` varchar(10) NOT NULL,
  `placa` varchar(6) NOT NULL,
  `valor` int(11) NOT NULL,
  `fe_pago` date NOT NULL,
  `cancela` enum('1','2') NOT NULL,
  `val_abono` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `parqueadero`
--

INSERT INTO `parqueadero` (`id`, `num_cedula`, `nombre`, `telefono`, `placa`, `valor`, `fe_pago`, `cancela`, `val_abono`) VALUES
(1, '1234567898', 'weww', '3424432434', 'dsr344', 12345, '2020-12-07', '2', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

DROP TABLE IF EXISTS `perfil`;
CREATE TABLE IF NOT EXISTS `perfil` (
  `idperfil` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) COLLATE latin1_spanish_ci NOT NULL,
  `activo` enum('Y','N') COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`idperfil`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `perfil`
--

INSERT INTO `perfil` (`idperfil`, `nombre`, `activo`) VALUES
(1, 'Admin', 'Y');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL,
  `perfil` int(11) NOT NULL,
  `usuario` varchar(60) COLLATE latin1_spanish_ci NOT NULL,
  `pass` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `nom_comple` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `fec_creaci` datetime DEFAULT NULL,
  `fec_modifi` datetime DEFAULT NULL,
  `activo` enum('Y','N') COLLATE latin1_spanish_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `perfil`, `usuario`, `pass`, `nom_comple`, `fec_creaci`, `fec_modifi`, `activo`) VALUES
(0, 1, 'Admin', 'Admin', 'Admin', '2020-11-29 00:00:00', '2020-11-29 00:00:00', 'Y');
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
